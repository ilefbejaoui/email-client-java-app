Basic Email Client using Java Swing.
This is a starter UI without email functionalities.
